package kr.co.hanbit.sqlite

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Memo(var no:Long?, var content:String, var datetime:Long)

class SqliteHelper(context: Context, name:String, version:Int) //SqliteHelper가 SQLiteopenHelper를 상속받아서 만든거기때문에 부모기능 다 쓸 수 있어.
    : SQLiteOpenHelper(context, name, null, version) {



    override fun onCreate(db: SQLiteDatabase?) {
        val create = "create table memo (`no` integer primary key, content text, datetime integer) " //`이거 붙이면 예약어도 컬럼명으로 사용가능
        db?.execSQL(create) //명령어인 쿼리(create)를 던져주면 돼 <쿼리 실행>
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // 테이블에 변경 사항이 있을 경우 호출됨
        // sqliteHelper()의 생성자를 호출할 때 기존 데이터베이스와 vesion을 비교해서 높으면 호출된다
    }

    // 데이터 입력 함수
    fun insertMemo(memo: Memo) { //입력을 받으면 db넣어주기만 하면돼 / data class Memo의 값을 받아서 insertMemo 함수로 던져주기만하면 db에 저장돼. 앱을 껐다켜도 남아있어
        // db 가져오기
        val wd = writableDatabase // 이거 이미 만들어져잇는 기능 (db꺼내)
        // Memo를 입력타입으로 변환
        val values = ContentValues()
        values.put("content", memo.content)
        values.put("datetime", memo.datetime)

        // db에 넣기
        wd.insert("memo", null, values) // 테이블이름, null, 값(Content Values 라고 정해져있음)
        // db 닫기
        wd.close()
    }
    // 데이터 조회함수
    fun selectMemo() : MutableList<Memo> {
        val list = mutableListOf<Memo>() // 이렇게 반환값이 있으면 반환타입을 먼저 지정하고 return list 해주면 가운데에 코드를 짜기만하면돼 가운데 비우고 전달하면 빈 리스트가 전달돼니까 값 채워

        val select = "select * from memo" // select 컬럼 no, content, datetime from memo 인데 모든 컬럼을 다 가져오려고 하면 앞에 코드처럼 써줘 / 앞에거 해석 : memo컬럼에서 select 모든컬럼해라
        val rd = readableDatabase // 읽어오기 위해서 database 가져와
        val cursor = rd.rawQuery(select, null) // <얘도 쿼리를 만들어서 던져 실행/ execSQL하고 다른점 : rawQuery는 반환값을 받아  >
        //cursor는 일종의 리스트같은거라 반복문을 돌면서 꺼낼 수 있다.
        while(cursor.moveToNext()) { // 여러줄의 데이터를 긁어와서 첫번째 줄을 가리킨다.
            val no = cursor.getLong(cursor.getColumnIndex("no")) // 이름이 no인 컬럼의 인덱스를 가져오고, 몇번째인지 getLong에 알려줘야해 대체로 0번째겠죠? 그 0번째값을 꺼내서 넣어
            val content = cursor.getString(cursor.getColumnIndex("content"))
            val datetime = cursor.getLong(cursor.getColumnIndex("datetime"))

            val memo = Memo(no, content, datetime)
            list.add(memo) //memo 클래스를 하나씩 담아 / memo 타입을 하나씩 담아서 반환

        }
        cursor.close()
        rd.close() //db도 close 해줘야돼. 메모리때문에 꼭!
        return list
    }
    // 데이터 수정함수
    fun updateMemo(memo:Memo) {
        val wd = writableDatabase

        val values = ContentValues()
        values.put("content", memo.content)
        values.put("datetime", memo.datetime)

        wd.update("memo", values, "no = ${memo.no}", null) //update란 date도 insert할때처럼 ContenValues() 타입으로 변환해줘야되니까 위에꺼 복사 붙여넣기해
        wd.close()
    }
    // 데이터 삭제함수
    fun deleteMemo(memo:Memo) {
        val wd = writableDatabase
 //       val delete = "delete from memo where no = ${memo.no}" // delete from 테이블 어디를 no = memo의 no랑 같은 데이터를 삭제해라
  //      wd.execSQL(delete)

        wd.delete("memo", "no=${memo.no}", null) // 위에 주석 이렇게 한줄로 처리 가능
        wd.close()
    }



}




