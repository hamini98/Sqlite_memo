package kr.co.hanbit.sqlite

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_recycler.view.*
import java.text.SimpleDateFormat

class RecyclerAdapter : RecyclerView.Adapter<Holder>() {
    var listData = mutableListOf<Memo>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder { // 화면에 보이는 개수만큼의 holer 생성
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recycler, parent, false)

        return Holder(view) // 생성한 view넣은 Holder로 리턴

    }

    override fun onBindViewHolder(holder: Holder, position: Int) { // 실제 화면에 그려주는 함수
        val memo = listData.get(position) // list data의 현재 위치를 꺼내줘
        holder.setMemo(memo)



    }

    override fun getItemCount(): Int { // '내가 몇줄을 그릴거야' 안드로이드에 알려줘
        return listData.size

    }
}

class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {  // Holer 클래스는 생성될때 itemview를 하나 가지고 생성되야한다. 상속받아서 구현되는 RecyClerview 홀더가 itemView를 넘겨받아서
    fun setMemo(memo: Memo) { // 꺼낸 데이터를 Holder의 setMemo로 사용
        itemView.textNo.text = "${memo.no}"
        itemView.textContent.text = "${memo.content}"
        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm") // 이 포맷의 날짜 형태로 바껴서
        val datetime = sdf.format(memo.datetime) // 반환이 돼
        itemView.textDatetime.text ="$datetime"
    }

}