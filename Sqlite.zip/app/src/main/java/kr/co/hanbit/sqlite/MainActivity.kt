package kr.co.hanbit.sqlite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val DB_NAME = "sqlite.sql"
    val DB_VERSION = 1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val helper = SqliteHelper(this, DB_NAME, DB_VERSION)
        val adapter = RecyclerAdapter()

        val memos = helper.selectMemo() // sqlite에 들어와있는 데이터 읽어서 넣어줄거야
        adapter.listData.addAll(memos) // 기존의 데이터에 추가로 집어넣어

        recyclerMemo.adapter = adapter
        recyclerMemo.layoutManager = LinearLayoutManager(this)

        buttonSave.setOnClickListener {
            val content = editMemo.text.toString()
            Log.d("메모", "content=$content")
            if(content.isNotEmpty()) {
                val memo = Memo(null, content, System.currentTimeMillis())
                helper.insertMemo(memo)
                Log.d("메모", "content is not empty")
                // 기존 작성글 삭제
                editMemo.setText("")
                // 목록 갱신
                adapter.listData.clear()
                adapter.listData.addAll(helper.selectMemo())
                adapter.notifyDataSetChanged()
            }
        }

      //  val memo = Memo(1, "내용", 123154546)
     //   helper.insertMemo(memo)
    }
}